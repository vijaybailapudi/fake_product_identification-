import smtplib as smtp
connection = smtp.SMTP_SSL('smtp.gmail.com', 465)
	
email_addr = 'sathyakumar17112022@gmail.com'
email_passwd = 'ncfplwzacztjnxyp'
connection.login(email_addr, email_passwd)
connection.sendmail(from_addr=email_addr, to_addrs='mahalakshmitg21@gmail.com',msg="FAKE PRODUCT ")
connection.close()